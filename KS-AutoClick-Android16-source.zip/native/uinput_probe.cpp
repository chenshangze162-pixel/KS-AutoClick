// Standalone diagnostic/reference only. Do not run a click loop until the
// device's multitouch protocol, ABS ranges, display rotation and SELinux policy
// have been verified on the target ROM.
#include <fcntl.h>
#include <linux/uinput.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <cerrno>
#include <cstdio>
#include <cstring>

int main() {
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    if (fd < 0) {
        std::fprintf(stderr, "open /dev/uinput failed: %s\n", std::strerror(errno));
        return 1;
    }
    std::puts("Opened /dev/uinput. Probe only; no virtual device created.");
    close(fd);
    return 0;
}
