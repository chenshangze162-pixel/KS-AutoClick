# Native uinput probe

This small C++ probe only tests whether a process can open `/dev/uinput`.
It deliberately does not create a virtual device or inject touch events.
A successful open is not proof that the device's touch protocol is configured
correctly. Keep SELinux enforcing; do not use `setenforce 0` as a workaround.
