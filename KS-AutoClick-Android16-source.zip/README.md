# KS AutoClick (Android 16)

This revision implements basic rooted tap automation using the Android `input tap X Y` command through a `su` shell.

## Features
- Manual X/Y coordinates
- Floating crosshair overlay to save an approximate screen coordinate
- ROOT permission check
- Start/stop repeated taps
- Configurable interval (minimum 20 ms) and count (0 means unlimited)

## Requirements and limitations
- Android device with KernelSU/Magisk or another working `su` provider.
- Grant ROOT access to KS AutoClick when prompted.
- Grant "Display over other apps" to use the floating crosshair.
- This implementation uses `input tap`, not native uinput. It depends on the device's root policy and Android build. The app must remain alive while tapping; do not force-stop it during a run.
- The crosshair coordinate is approximate. Verify X/Y on the target screen before using long runs.
- Start with a small finite count to test. The app does not guarantee compatibility with every game or protected app.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK installed. APK output: `app/build/outputs/apk/debug/app-debug.apk`.
