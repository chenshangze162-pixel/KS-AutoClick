# KS AutoClick — Android 16 starter project

这是一个 Android Studio 起步工程（源码，不是已编译 APK），目标设备为 Redmi K70 Pro / Android 16 / KernelSU。

## 当前原型包含
- Kotlin 主界面与悬浮窗权限引导
- 悬浮准星：拖动选择屏幕坐标并锁定
- 点击间隔、次数设置界面
- Root/uinput 环境诊断入口
- C++ uinput 触控注入参考实现（独立 native 源码）

## 重要限制
你的设备报告 `CONFIG_INPUT_UINPUT=y` 且 `/dev/uinput` 存在，但 SELinux 为 `Enforcing`，设备节点标签为 `u:object_r:uhid_device:s0`。这不能证明 Root 服务一定能打开并创建触控设备。原型会先做能力检测；若被 SELinux 拒绝，会明确报错，不会关闭 SELinux、修改策略或改写原厂内核。

此工程尚未完成 Android 16 真机验证，也不是可直接安装的 APK。请用 Android Studio 打开项目，安装 Android SDK 35/36 和 NDK 后构建。完成构建后还需在真机上验证 uinput 的 ABS 轴范围、触控槽位协议及 SELinux AVC 日志。

## 构建
1. Android Studio 打开本目录。
2. 安装 Android SDK 35、Android Gradle Plugin 所需 Gradle 版本及 NDK。
3. Sync Project，先运行 Kotlin UI 原型。
4. 原生注入部分仅作为后续集成代码，不能在未验证设备协议前直接用于连续点击。

## 建议的下一阶段
- 用 `getevent -lp` 读取真实触屏设备的 ABS 范围与协议。
- 用 `dmesg` 或 `logcat` 检查是否有 uinput / SELinux 拒绝记录。
- 再确定虚拟设备使用单点还是 multitouch 协议。
