package com.example.ksautoclick

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var countInput: EditText
    private val running = AtomicBoolean(false)
    @Volatile private var rootProcess: Process? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "KS AutoClick"; textSize = 26f })
        status = TextView(this).apply {
            text = "状态：待启动\n点击方式：KernelSU / su 执行 input tap"
            textSize = 14f
            setPadding(0, pad, 0, pad)
        }
        root.addView(status)
        xInput = numberField("X 坐标", "500")
        yInput = numberField("Y 坐标", "900")
        intervalInput = numberField("点击间隔（毫秒）", "100")
        countInput = numberField("点击次数（0 = 无限）", "0")
        root.addView(xInput); root.addView(yInput)
        root.addView(intervalInput); root.addView(countInput)

        root.addView(Button(this).apply {
            text = "打开悬浮准星选择坐标"
            setOnClickListener {
                if (!android.provider.Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:$packageName")))
                } else startService(Intent(this@MainActivity, CrosshairService::class.java))
            }
        })
        root.addView(Button(this).apply {
            text = "检查 ROOT 权限"
            setOnClickListener { checkRoot() }
        })
        root.addView(Button(this).apply {
            text = "开始自动点击"
            setOnClickListener { startClicking() }
        })
        root.addView(Button(this).apply {
            text = "停止点击"
            setOnClickListener { stopClicking() }
        })
        root.addView(TextView(this).apply {
            text = "说明：点击通过 su 调用系统 input tap。需在 KernelSU 中允许本应用获取 ROOT。首次请先用少量次数测试。"
            textSize = 13f
            setPadding(0, pad, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun numberField(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setText(value)
        textSize = 18f
        setSingleLine(true)
    }

    private fun checkRoot() {
        status.text = "正在检查 ROOT..."
        Thread {
            val result = runCatching {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val out = p.inputStream.bufferedReader().readText().trim()
                val code = p.waitFor()
                if (code == 0 && out.contains("uid=0")) "ROOT 可用：$out" else "ROOT 不可用：$out"
            }.getOrElse { "ROOT 检查失败：${it.message}" }
            runOnUiThread { status.text = result }
        }.start()
    }

    private fun startClicking() {
        if (running.get()) return
        val x = xInput.text.toString().toIntOrNull()
        val y = yInput.text.toString().toIntOrNull()
        val interval = intervalInput.text.toString().toLongOrNull()
        val count = countInput.text.toString().toLongOrNull()
        if (x == null || y == null || interval == null || count == null || x < 0 || y < 0 || interval < 20 || count < 0) {
            status.text = "参数错误：坐标和次数须为非负整数，间隔不能小于 20ms"
            return
        }
        running.set(true)
        status.text = "正在请求 ROOT 并启动点击..."
        Thread {
            var taps = 0L
            try {
                val process = Runtime.getRuntime().exec("su")
                rootProcess = process
                val writer = BufferedWriter(OutputStreamWriter(process.outputStream))
                writer.write("id\n"); writer.flush()
                val reader = process.inputStream.bufferedReader()
                // 读取 id 输出，确认 su shell 已启动
                val identity = reader.readLine() ?: ""
                if (!identity.contains("uid=0")) throw IllegalStateException("未获得 ROOT 授权：$identity")
                while (running.get() && (count == 0L || taps < count)) {
                    writer.write("input tap $x $y\n")
                    writer.flush()
                    taps++
                    if (count == 0L || taps < count) Thread.sleep(interval)
                }
                writer.write("exit\n"); writer.flush()
                process.waitFor()
                runOnUiThread { status.text = "已完成：点击 $taps 次（坐标 $x, $y）" }
            } catch (e: InterruptedException) {
                runOnUiThread { status.text = "已停止：已发送 $taps 次点击" }
            } catch (e: Exception) {
                runOnUiThread { status.text = if (!running.get()) "已停止：已发送 $taps 次点击" else "点击失败：${e.message}" }
            } finally {
                running.set(false)
                rootProcess?.destroy()
                rootProcess = null
            }
        }.start()
    }

    private fun stopClicking() {
        if (running.getAndSet(false)) {
            rootProcess?.destroy()
            status.text = "正在停止点击..."
        } else status.text = "当前没有正在运行的点击任务"
    }

    override fun onResume() {
        super.onResume()
        val prefs = getSharedPreferences("autoclick", MODE_PRIVATE)
        if (prefs.contains("x")) xInput.setText(prefs.getInt("x", 0).toString())
        if (prefs.contains("y")) yInput.setText(prefs.getInt("y", 0).toString())
    }

    override fun onDestroy() {
        stopClicking()
        super.onDestroy()
    }
}
