package com.example.ksautoclick

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var xValue: TextView
    private lateinit var yValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "KS AutoClick"
            textSize = 26f
        })
        status = TextView(this).apply {
            text = "原型状态：尚未进行 uinput 真机验证"
            textSize = 14f
            setPadding(0, 18, 0, 18)
        }
        root.addView(status)
        xValue = TextView(this).apply { text = "X：未选择"; textSize = 18f }
        yValue = TextView(this).apply { text = "Y：未选择"; textSize = 18f }
        root.addView(xValue)
        root.addView(yValue)

        val choose = Button(this).apply {
            text = "打开悬浮准星"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, CrosshairService::class.java))
                }
            }
        }
        root.addView(choose)

        val interval = EditText(this).apply {
            hint = "点击间隔（毫秒），例如 100"
            inputType = 2
            setText("100")
        }
        root.addView(interval)

        val count = EditText(this).apply {
            hint = "点击次数，0 表示无限"
            inputType = 2
            setText("0")
        }
        root.addView(count)

        val diag = Button(this).apply {
            text = "检查 Root / uinput"
            setOnClickListener {
                Thread {
                    val result = runCatching {
                        val p = Runtime.getRuntime().exec(arrayOf("su", "-c",
                            "id; ls -l /dev/uinput; getenforce; uname -r"))
                        val output = p.inputStream.bufferedReader().readText()
                        val err = p.errorStream.bufferedReader().readText()
                        p.waitFor()
                        output + if (err.isNotBlank()) "\n$err" else ""
                    }.getOrElse { "检查失败：${it.message}" }
                    runOnUiThread { status.text = result }
                }.start()
            }
        }
        root.addView(diag)
        root.addView(TextView(this).apply {
            text = "提示：本版本只实现准星坐标选择和环境诊断；点击注入需完成设备协议与 SELinux 验证后再启用。"
            textSize = 13f
            setPadding(0, 20, 0, 0)
        })
        setContentView(root)
    }

    fun updateCoordinates(x: Int, y: Int) {
        xValue.text = "X：$x"
        yValue.text = "Y：$y"
    }
}
