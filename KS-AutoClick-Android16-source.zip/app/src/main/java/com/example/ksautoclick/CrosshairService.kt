package com.example.ksautoclick

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class CrosshairService : Service() {
    private lateinit var wm: WindowManager
    private var marker: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var downX = 0f
    private var downY = 0f
    private var baseX = 0
    private var baseY = 0
    private var moved = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "＋\n拖动准星到目标位置\n松开保存坐标"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC202020.toInt())
            setPadding(14, 10, 14, 10)
            setOnTouchListener { v, event ->
                val p = params ?: return@setOnTouchListener false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX; downY = event.rawY
                        baseX = p.x; baseY = p.y; moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).roundToInt()
                        val dy = (event.rawY - downY).roundToInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 5) moved = true
                        p.x = baseX + dx; p.y = baseY + dy
                        wm.updateViewLayout(v, p)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            val x = (p.x + v.width / 2).coerceAtLeast(0)
                            val y = (p.y + v.height / 2).coerceAtLeast(0)
                            getSharedPreferences("autoclick", MODE_PRIVATE).edit().putInt("x", x).putInt("y", y).apply()
                            Toast.makeText(this@CrosshairService, "坐标已保存：$x, $y。返回主界面即可使用", Toast.LENGTH_LONG).show()
                        } else stopSelf()
                        true
                    }
                    else -> false
                }
            }
        }
        marker = view
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 120; y = 300 }
        params = lp
        wm.addView(view, lp)
    }

    override fun onDestroy() {
        marker?.let { runCatching { wm.removeView(it) } }
        marker = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
