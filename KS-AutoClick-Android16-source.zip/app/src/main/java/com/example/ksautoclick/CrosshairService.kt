package com.example.ksautoclick

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.roundToInt

class CrosshairService : Service() {
    private lateinit var wm: WindowManager
    private var marker: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var downX = 0f
    private var downY = 0f
    private var baseX = 0
    private var baseY = 0

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "＋\n拖动准星；点按锁定并退出"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(0xAA202020.toInt())
            setPadding(18, 12, 18, 12)
            setOnTouchListener { v, event ->
                val p = params ?: return@setOnTouchListener false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX; downY = event.rawY
                        baseX = p.x; baseY = p.y
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = baseX + (event.rawX - downX).roundToInt()
                        p.y = baseY + (event.rawY - downY).roundToInt()
                        wm.updateViewLayout(v, p)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        // 坐标是悬浮窗中心的屏幕近似坐标；正式注入前需按显示旋转和 inset 校准。
                        val x = (p.x + v.width / 2).coerceAtLeast(0)
                        val y = (p.y + v.height / 2).coerceAtLeast(0)
                        android.widget.Toast.makeText(this, "已选坐标：$x, $y", android.widget.Toast.LENGTH_SHORT).show()
                        true
                    }
                    else -> false
                }
            }
        }
        marker = view
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 120; y = 300 }
        params = lp
        wm.addView(view, lp)
    }

    override fun onDestroy() {
        marker?.let { runCatching { wm.removeView(it) } }
        marker = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
